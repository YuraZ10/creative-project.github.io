import pygame
import sys
import random

def mini_game_menu(screen):
    width = 480
    height = 800
    
    bg = pygame.image.load('images/bg.png').convert()

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)
    pyFontSmall = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22)
    pyFontBig = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 66)

    mini_game_text = pyFont.render('Collect The Target', True, (0, 0, 0), (0, 0, 255))
    mini_game_text_rect = mini_game_text.get_rect(center=(width // 2, cross_rect.bottom + 50))

    mini_game_text2 = pyFontSmall.render('Goal: collect the target', True, (0, 0, 0), (255, 255, 255))
    mini_game_text2_rect = mini_game_text2.get_rect(center=(width // 2, mini_game_text_rect.bottom + 50))

    mini_game_text3 = pyFontSmall.render('in 4 seconds.', True, (0, 0, 0), (255, 255, 255))
    mini_game_text3_rect = mini_game_text3.get_rect(center=(width / 2, mini_game_text2_rect.bottom + (mini_game_text3.get_height() / 2)))

    mini_game_text4 = pyFontSmall.render('Move: W, A, S, D or', True, (0, 0, 0), (255, 255, 255))
    mini_game_text4_rect = mini_game_text4.get_rect(
        center=(width / 2, mini_game_text3_rect.bottom + 50))

    mini_game_text5 = pyFontSmall.render('arrows Up, Left, Down, Right.', True, (0, 0, 0), (255, 255, 255))
    mini_game_text5_rect = mini_game_text5.get_rect(
        center=(width / 2, mini_game_text4_rect.bottom + 10))

    play_button = pyFontBig.render('PLAY!', True, (255, 255, 255), (0, 0, 0))
    play_button_rect = play_button.get_rect(center=(width // 2, height - (play_button.get_height() / 2) - 100))

    button_pressed = False

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.game_menu()
            if play_button_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    mini_game(screen)

        screen.blit(bg, (0, 0))

        screen.blit(cross, cross_rect)

        screen.blit(mini_game_text, mini_game_text_rect)
        screen.blit(mini_game_text2, mini_game_text2_rect)
        screen.blit(mini_game_text3, mini_game_text3_rect)
        screen.blit(mini_game_text4, mini_game_text4_rect)
        screen.blit(mini_game_text5, mini_game_text5_rect)

        screen.blit(play_button, play_button_rect)

        pygame.display.flip()

def mini_game(screen):
    width = 480
    height = 800

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)

    bg = pygame.image.load('images/bg.png').convert()

    player_width, player_height = 50, 50
    px = width // 2 - player_width / 2
    py = height // 2 - player_height / 2
    player_speed = 5

    target_width, target_height = 25, 25
    tx = random.randint(0, width - target_width)
    ty = random.randint(0, height - target_height)

    global score
    score = 0
    time_limit = 120
    timer = time_limit

    def check_collision(player_pos, target_pos):
        p_x, p_y = px, py
        t_x, t_y = tx, ty

        if (p_x < t_x < p_x + player_width or p_x < t_x + target_width < p_x + player_width) and \
                (p_y < t_y < p_y + player_height or p_y < t_y + target_height < p_y + player_height):
            return True
        return False

    clock = pygame.time.Clock()

    button_pressed = False

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            px -= player_speed
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            px += player_speed
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            py -= player_speed
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            py += player_speed

        px = max(0, min(px, width - player_width))
        py = max(0, min(py, height - player_height))

        screen.blit(bg, (0, 0))

        timer -= 1
        timer_text = pyFont.render(f"Time: {timer // 30 + 1}", True, (0, 0, 0), (255, 255, 255))
        timer_text_rect = timer_text.get_rect(topright=(width - 10, 10))
        screen.blit(timer_text, timer_text_rect)

        score_text = pyFont.render(f"Score: {score}", True, (0, 0, 0), (255, 255, 255))
        score_text_rect = score_text.get_rect(topleft=(10, 10))
        screen.blit(score_text, score_text_rect)

        pygame.draw.rect(screen, (0, 0, 255), (px, py, player_width, player_height))
        pygame.draw.rect(screen, (255, 0, 0), (tx, ty, target_width, target_height))

        if check_collision(px, py):
            score += 1
            timer = time_limit

            tx = random.randint(0, width - target_width)
            ty = random.randint(0, height - target_height)

        if timer <= 0:
            end(screen)

        pygame.display.flip()
        clock.tick(30)

def end(screen):
    width = 480
    height = 800

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)

    bg = pygame.image.load('images/bg.png').convert()

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    money_got = score * 5

    with open("money.txt", "r") as money:
        lines = money.readlines()
        line_money = int(lines[0].strip())
    line_money += money_got
    with open('money.txt', "w") as money:
        money.write(str(line_money))

    end_text = pyFont.render('Collect The Target', True, (0, 0, 0), (255, 255, 255))
    end_text_rect = end_text.get_rect(center=(width // 2, cross_rect.bottom + 50))

    end_text2 = pyFont.render(f'Your score: {score}.', True, (0, 0, 0), (255, 255, 255))
    end_text2_rect = end_text2.get_rect(center=(width // 2, end_text_rect.bottom + 50))

    end_text3 = pyFont.render(f'You got {money_got}$.', True, (0, 0, 0), (255, 255, 255))
    end_text3_rect = end_text3.get_rect(center=(width // 2, end_text2_rect.bottom + 50))

    button_pressed = False

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.game_menu()

        screen.blit(bg, (0, 0))
        screen.blit(cross, cross_rect)

        screen.blit(end_text, end_text_rect)
        screen.blit(end_text2, end_text2_rect)
        screen.blit(end_text3, end_text3_rect)

        pygame.display.flip()
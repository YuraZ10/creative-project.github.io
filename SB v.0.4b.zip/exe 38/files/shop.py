import pygame
import sys
import random
import time
import os

def shop(screen):
    width = 480
    height = 800

    bg = pygame.image.load('images/bg.png').convert()

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)
    pyFontSmall = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22)
    pyFontBig = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 66)

    shop_text = pyFontBig.render('SHOP', True, (0, 0, 0), (255, 255, 255))
    shop_text_rect = shop_text.get_rect(center=(width // 2, height // 9))

    gifts_text = pyFont.render('IN DEVELOPMENT', True, (0, 0, 0), (255, 255, 255))
    gifts_text_rect = gifts_text.get_rect(center=(width // 2, shop_text_rect.bottom + 50))

    common_text = pyFontSmall.render('Common - 100$', True, (255, 255, 255), (0, 0, 0))
    common_text_rect = common_text.get_rect(center=(width // 2, gifts_text_rect.bottom + 50))

    rare_text = pyFontSmall.render('Rare - 225$', True, (255, 255, 255), (0, 0, 0))
    rare_text_rect = rare_text.get_rect(center=(width // 2, gifts_text_rect.bottom + 50))

    epic_text = pyFontSmall.render('Epic - 375$', True, (255, 255, 255), (0, 0, 0))
    epic_text_rect = epic_text.get_rect(center=(width // 2, gifts_text_rect.bottom + 50))

    mythic_text = pyFontSmall.render('Mythic - 750$', True, (255, 255, 255), (0, 0, 0))
    mythic_text_rect = mythic_text.get_rect(center=(width // 2, gifts_text_rect.bottom + 50))

    legendary_text = pyFontSmall.render('Legendary - 1500$', True, (255, 255, 255), (0, 0, 0))
    legendary_text_rect = legendary_text.get_rect(center=(width // 2, gifts_text_rect.bottom + 50))

    money_gift = random.randrange(50, 501, 5)
    money_gift_text = pyFontSmall.render(f'{money_gift}$', True, (255, 255, 255), (0, 0, 0))
    money_gift_text_rect = money_gift_text.get_rect(center=(width // 2, gifts_text_rect.bottom + 50))

    gifts = [[money_gift_text, money_gift_text_rect], [common_text, common_text_rect], [rare_text, rare_text_rect],
             [epic_text, epic_text_rect], [mythic_text, mythic_text_rect], [legendary_text, legendary_text_rect]]

    def get_last_gift_time():
        if os.path.exists('last_gift_time.txt'):
            with open('last_gift_time.txt', 'r') as file:
                last_gift_time_str = file.read().strip()
                if last_gift_time_str:
                    return float(last_gift_time_str)
        return 0

    def save_gift_time(current_time):
        with open('last_gift_time.txt', 'w') as file:
            file.write(str(current_time))

    def is_24_hours_passed():
        current_time = time.time()
        last_gift_time = get_last_gift_time()
        if current_time - last_gift_time >= 1:
            return True
        return False

    button_pressed = False

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.main_menu()

        screen.blit(bg, (0, 0))

        screen.blit(shop_text, shop_text_rect)
        screen.blit(cross, cross_rect)

        screen.blit(gifts_text, gifts_text_rect)
        # screen.blit(common_text, common_text_rect)
        # screen.blit(rare_text, rare_text_rect)
        # screen.blit(epic_text, epic_text_rect)
        # screen.blit(mythic_text, mythic_text_rect)
        # screen.blit(legendary_text, legendary_text_rect)

        # if is_24_hours_passed():
        #     daily_gift = random.choice(gifts)
        #     screen.blit(daily_gift[0], daily_gift[1])
        #     save_gift_time(time.time())
        # else:
        #     no_gift_text = pyFontSmall.render('Next gift available in 24 hours.', True, (0, 0, 0), (255, 255, 255))
        #     no_gift_text_rect = no_gift_text.get_rect(center=(width // 2, gifts_text_rect.bottom + 150))
        #     screen.blit(no_gift_text, no_gift_text_rect)

        pygame.display.flip()
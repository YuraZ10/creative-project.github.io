import pygame
import sys
import random

def card_choice_menu(screen, current_chest_index):
    width = 480
    height = 800

    bg = pygame.image.load('images/bg.png').convert()

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)

    card_stickman = [pygame.image.load('cards/card_stickman.png'), 'Stickman']
    card_manstick = [pygame.image.load('cards/card_manstick.png'), 'namkcitS']
    card_killer = [pygame.image.load('cards/card_killer.png'), 'Robot-Killer']

    card_robot = [pygame.image.load('cards/card_robot.png'), 'Stickman-Robot']
    card_mewing = [pygame.image.load('cards/card_mewing.png'), 'Mewing Stickman']
    card_punk = [pygame.image.load('cards/card_punk.png'), 'Stickman Punk']

    card_stickman_superman = [pygame.image.load('cards/card_stickman_superman.png'), 'SuperStickman']
    card_jojo = [pygame.image.load('cards/card_jojo.png'), 'Stickman... what?']
    card_muscles = [pygame.image.load('cards/card_muscles.png'), 'Muscular']
    card_ninja = [pygame.image.load('cards/card_ninja.png'), 'Stickman Ninja']
    card_knight = [pygame.image.load('cards/card_knight.png'), 'Stickman Knight']
    card_solider = [pygame.image.load('cards/card_solider.png'), 'Stickman Solider']

    card_angel = [pygame.image.load('cards/card_angel.png'), 'Angel']
    card_demon = [pygame.image.load('cards/card_demon.png'), 'Demon']
    card_cowboy = [pygame.image.load('cards/card_cowboy.png'), 'Cowboy']
    card_reaper = [pygame.image.load('cards/card_reaper.png'), 'Reaper']

    card_face = [pygame.image.load('cards/card_face.png'), 'Face']
    card_freddy = [pygame.image.load('cards/card_freddy.png'), 'Freddy']

    common_cards = [card_stickman, card_manstick, card_killer]
    rare_cards = [card_robot, card_mewing, card_punk]
    epic_cards = [card_stickman_superman, card_jojo, card_muscles, card_ninja, card_knight, card_solider]
    mythic_cards = [card_angel, card_demon, card_cowboy, card_reaper]
    legendary_cards = [card_face, card_freddy]

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    percent = random.random()

    if current_chest_index == 0:
        chest = pygame.image.load('images/chest.png').convert()
        if percent <= 0.7:
            current_card = random.choice(common_cards)
            card_price = 5
        elif percent <= 0.9:
            current_card = random.choice(rare_cards)
            card_price = 10
        elif percent <= 0.97:
            current_card = random.choice(epic_cards)
            card_price = 25
        elif percent <= 0.99:
            current_card = random.choice(mythic_cards)
            card_price = 50
        else:
            current_card = random.choice(legendary_cards)
            card_price = 100

    elif current_chest_index == 1:
        chest = pygame.image.load('images/chest_rare.png').convert()
        if percent <= 0.5:
            current_card = random.choice(common_cards)
            card_price = 5
        elif percent <= 0.8:
            current_card = random.choice(rare_cards)
            card_price = 10
        elif percent <= 0.95:
            current_card = random.choice(epic_cards)
            card_price = 25
        elif percent <= 0.99:
            current_card = random.choice(mythic_cards)
            card_price = 50
        else:
            current_card = random.choice(legendary_cards)
            card_price = 100

    elif current_chest_index == 2:
        chest = pygame.image.load('images/chest_epic.png').convert()
        if percent <= 0.2:
            current_card = random.choice(common_cards)
            card_price = 5
        elif percent <= 0.4:
            current_card = random.choice(rare_cards)
            card_price = 10
        elif percent <= 0.75:
            current_card = random.choice(epic_cards)
            card_price = 25
        elif percent <= 0.95:
            current_card = random.choice(mythic_cards)
            card_price = 50
        else:
            current_card = random.choice(legendary_cards)
            card_price = 100

    elif current_chest_index == 3:
        chest = pygame.image.load('images/chest_mithic.png').convert()
        if percent <= 0.1:
            current_card = random.choice(common_cards)
            card_price = 5
        elif percent <= 0.2:
            current_card = random.choice(rare_cards)
            card_price = 10
        elif percent <= 0.5:
            current_card = random.choice(epic_cards)
            card_price = 25
        elif percent <= 0.9:
            current_card = random.choice(mythic_cards)
            card_price = 50
        else:
            current_card = random.choice(legendary_cards)
            card_price = 100

    elif current_chest_index == 4:
        chest = pygame.image.load('images/chest_legendary.png').convert()
        if percent <= 0.00:
            current_card = random.choice(common_cards)
            card_price = 5
        elif percent <= 0.1:
            current_card = random.choice(rare_cards)
            card_price = 10
        elif percent <= 0.40:
            current_card = random.choice(epic_cards)
            card_price = 25
        elif percent <= 0.75:
            current_card = random.choice(mythic_cards)
            card_price = 50
        else:
            current_card = random.choice(legendary_cards)
            card_price = 100

    chest_rect = chest.get_rect()
    chest_rect.center = (width // 2, height // 2)

    scale = 0.5
    scaling_speed = 0.01

    card_img = current_card[0]
    card_name = current_card[1]

    # card_rect = card_img.get_rect()
    # card_rect.center = (width // 2, height // 2)

    with open("inventory.txt", "r") as inventory:
        lines = inventory.readlines()

    lines = [line.strip() for line in lines]

    if card_name in lines:
        card_type_text = pyFont.render(f'Duplicate! + {card_price}$', True, (0, 0, 0), (255, 255, 255))

        with open("money.txt", "r") as money:
            lines = money.readlines()
            line_money = int(lines[0].strip())
            line_money += card_price

        with open('money.txt', "w") as money:
            money.write(str(line_money))
    else:
        card_type_text = pyFont.render('New card!', True, (0, 0, 0), (255, 255, 255))

        with open("inventory.txt", "a") as inventory:
            inventory.write(card_name + "\n")

    button_pressed = False

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.main_menu()

        screen.blit(bg, (0, 0))

        new_width = int(chest_rect.width * scale)
        new_height = int(chest_rect.height * scale)
        scaled_chest = pygame.transform.scale(chest, (new_width, new_height))

        scaled_chest_rect = scaled_chest.get_rect()
        scaled_chest_rect.center = (width // 2, height // 2)

        screen.blit(scaled_chest, scaled_chest_rect)

        scale += scaling_speed
        if scale > 2.0:
            scale = 2.0
            # cards.random_card(screen, current_chest_index)
            screen.blit(bg, (0, 0))

            screen.blit(cross, cross_rect)

            card_type_text_rect = card_type_text.get_rect(center=(width // 2, cross_rect.bottom + 40))
            screen.blit(card_type_text, card_type_text_rect)

            card_rect = card_img.get_rect()
            card_rect.center = (width // 2, card_type_text_rect.bottom + 250)

            screen.blit(card_img, card_rect)

            card_name_text = pyFont.render(card_name, True, (0, 0, 0), (255, 255, 255))
            text_rect = card_name_text.get_rect(center=(width // 2, card_rect.bottom + 40))
            screen.blit(card_name_text, text_rect)


        pygame.display.flip()


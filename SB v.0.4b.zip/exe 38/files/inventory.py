import pygame
import sys


def inventory(screen):
    width = 480
    height = 800

    bg = pygame.image.load('images/bg.png').convert()
    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)
    pyFontSmall = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22)
    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    arrow_right = pygame.image.load('images/arrow_right.png')
    arrow_right_rect = arrow_right.get_rect(center=screen.get_rect().center)
    arrow_right_rect.x = width - arrow_right.get_width()
    arrow_right_rect.y = height - arrow_right.get_height()

    arrow_left = pygame.image.load('images/arrow_left.png')
    arrow_left_rect = arrow_left.get_rect(center=screen.get_rect().center)
    arrow_left_rect.x = 0
    arrow_left_rect.y = height - arrow_left.get_height()

    RARITY = {
        'Common': 0,
        'Rare': 1,
        'Epic': 2,
        'Mythic': 3,
        'Legendary': 4
    }

    cards = {
        'Stickman': ('cards/card_stickman.png', 'Common'),
        'namkcitS': ('cards/card_manstick.png', 'Common'),
        'Robot-Killer': ('cards/card_killer.png', 'Common'),

        'Stickman-Robot': ('cards/card_robot.png', 'Rare'),
        'Mewing Stickman': ('cards/card_mewing.png', 'Rare'),
        'Stickman Punk': ('cards/card_punk.png', 'Rare'),

        'SuperStickman': ('cards/card_stickman_superman.png', 'Epic'),
        'Stickman... what?': ('cards/card_jojo.png', 'Epic'),
        'Muscular': ('cards/card_muscles.png', 'Epic'),
        'Stickman Ninja': ('cards/card_ninja.png', 'Epic'),
        'Stickman Knight': ('cards/card_knight.png', 'Epic'),
        'Stickman Solider': ('cards/card_solider.png', 'Epic'),

        'Angel': ('cards/card_angel.png', 'Mythic'),
        'Demon': ('cards/card_demon.png', 'Mythic'),
        'Cowboy': ('cards/card_cowboy.png', 'Mythic'),
        'Reaper': ('cards/card_reaper.png', 'Mythic'),

        'Face': ('cards/card_face.png', 'Legendary'),
        'Freddy': ('cards/card_freddy.png', 'Legendary')
    }

    card_scale = 1.1

    with open('inventory.txt', 'r') as inventory:
        lines = inventory.readlines()

    collected_cards = [line.strip() for line in lines]

    sorted_collected_cards = sorted(collected_cards, key=lambda name: RARITY[cards[name][1]])

    current_card_index = 0
    if sorted_collected_cards:
        current_card_name = sorted_collected_cards[current_card_index]
        card_image_path, card_rarity = cards.get(current_card_name, (None, ""))
        if card_image_path:
            card_image = pygame.image.load(card_image_path)
            card_rect = card_image.get_rect(center=(width // 2, height // 2))
            new_width = int(card_rect.width / card_scale)
            new_height = int(card_rect.height / card_scale)
            scaled_card = pygame.transform.scale(card_image, (new_width, new_height))
            scaled_card_rect = scaled_card.get_rect(center=(width // 2, height // 2))
        else:
            card_image = None
            card_rect = None
    else:
        card_image = None
        card_rect = None
        current_card_name = "You don't have"
        no_card_text1 = pyFont.render(current_card_name, True, (0, 0, 0), (255, 255, 255))
        no_card_text1_rect = no_card_text1.get_rect(center=(width // 2, height // 2 - 25))
        current_card_name2 = "any card!"
        no_card_text2 = pyFont.render(current_card_name2, True, (0, 0, 0), (255, 255, 255))
        no_card_text2_rect = no_card_text2.get_rect(center=(width // 2, height // 2 + 25))

    RARITY_COLORS = {
        'Common': (0, 0, 0),
        'Rare': (0, 255, 0),
        'Epic': (255, 0, 255),
        'Mythic': (255, 0, 0),
        'Legendary': (255, 255, 0)
    }

    button_pressed = False
    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if arrow_right_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    current_card_index = (current_card_index + 1) % len(sorted_collected_cards)
                    if sorted_collected_cards:
                        current_card_name = sorted_collected_cards[current_card_index]
                        card_image_path, card_rarity = cards.get(current_card_name, (None, ""))
                        if card_image_path:
                            card_image = pygame.image.load(card_image_path)
                            card_rect = card_image.get_rect(center=(width // 2, height // 2))

                            new_width = int(card_rect.width / card_scale)
                            new_height = int(card_rect.height / card_scale)
                            scaled_card = pygame.transform.scale(card_image, (new_width, new_height))

                            scaled_card_rect = scaled_card.get_rect()
                            scaled_card_rect.center = (width // 2, height // 2)

                    else:
                        pass
            if arrow_left_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    current_card_index = (current_card_index - 1) % len(sorted_collected_cards)
                    if sorted_collected_cards:
                        current_card_name = sorted_collected_cards[current_card_index]
                        card_image_path, card_rarity = cards.get(current_card_name, (None, ""))
                        if card_image_path:
                            card_image = pygame.image.load(card_image_path)
                            card_rect = card_image.get_rect(center=(width // 2, height // 2))

                            new_width = int(card_rect.width / card_scale)
                            new_height = int(card_rect.height / card_scale)
                            scaled_card = pygame.transform.scale(card_image, (new_width, new_height))

                            scaled_card_rect = scaled_card.get_rect()
                            scaled_card_rect.center = (width // 2, height // 2)
                    else:
                        pass
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.main_menu()

        screen.blit(bg, (0, 0))

        if card_image:
            screen.blit(scaled_card, scaled_card_rect)

            collected_cards_count = len(sorted_collected_cards)
            total_cards = len(cards)
            collected_text1 = 'Cards collected:'
            collected_text1_text = pyFontSmall.render(collected_text1, True, (0, 0, 0), (255, 255, 255))
            collected_text1_rect = collected_text1_text.get_rect(midleft=(25, 25))
            collected_text2 = f'{collected_cards_count}/{total_cards}'
            collected_text2_text = pyFontSmall.render(collected_text2, True, (0, 0, 0), (255, 255, 255))
            collected_text2_rect = collected_text1_text.get_rect(midleft=(25, 25 + collected_text1_rect.height))

            screen.blit(collected_text1_text, collected_text1_rect)
            screen.blit(collected_text2_text, collected_text2_rect)

            card_name_text = pyFont.render(current_card_name, True, (0, 0, 0), (255, 255, 255))
            card_name_rect = card_name_text.get_rect(center=(width // 2, card_rect.bottom + 25))
            screen.blit(card_name_text, card_name_rect)

            card_rarity_color = RARITY_COLORS.get(card_rarity, (0, 0, 0))
            card_rarity_text = pyFont.render(card_rarity, True, card_rarity_color, (255, 255, 255))
            card_rarity_text_rect = card_rarity_text.get_rect(midleft=(25, card_rect.top - 25))
            screen.blit(card_rarity_text, card_rarity_text_rect)

            screen.blit(arrow_right, arrow_right_rect)
            screen.blit(arrow_left, arrow_left_rect)

            index_text = pyFont.render(f'{current_card_index + 1}', True, (0, 0, 0), (255, 255, 255))
            index_text_rect = index_text.get_rect(center=(width // 2, height - 40))
            screen.blit(index_text, index_text_rect)
        else:
            screen.blit(no_card_text1, no_card_text1_rect)
            screen.blit(no_card_text2, no_card_text2_rect)



        screen.blit(cross, cross_rect)
        pygame.display.flip()

import pygame
import random
import sys
import tkinter as tk
from tkinter import simpledialog
from tkinter import messagebox

def casino(screen):
    global color, bet_amount

    color = [None, False]
    bet_amount = 0

    root = tk.Tk()
    root.withdraw()

    width = 480
    height = 800

    bg = pygame.image.load('images/bg.png').convert()

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)
    pyFontSmall = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22)
    pyFontBig = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 66)

    casino_text = pyFont.render('Casino', True, (0, 0, 0), (255, 0, 0))
    casino_text_rect = casino_text.get_rect(center=(width // 2, height // 9))

    casino_text2 = pyFont.render('This is a roulette!', True, (0, 0, 0), (255, 0, 0))
    casino_text2_rect = casino_text2.get_rect(center=(width // 2, casino_text_rect.bottom + 55))

    casino_text3 = pyFontSmall.render('Enter your bet and choose a color,', True, (0, 0, 0), (255, 255, 255))
    casino_text3_rect = casino_text3.get_rect(center=(width // 2, casino_text2_rect.bottom + 25))

    casino_text4 = pyFontSmall.render('and you might win!', True, (0, 0, 0), (255, 255, 255))
    casino_text4_rect = casino_text4.get_rect(
        center=(width // 2, casino_text3_rect.bottom + (casino_text4.get_height() / 2)))

    bet_button = pyFont.render('Click, to enter', True, (255, 255, 255), (0, 0, 0))
    bet_button_rect = bet_button.get_rect(center=(width // 2, casino_text4_rect.bottom + 50))
    bet_button2 = pyFont.render('your bet', True, (255, 255, 255), (0, 0, 0))
    bet_button2_rect = bet_button2.get_rect(
        center=(width // 2, bet_button_rect.bottom + (bet_button2.get_height() / 2)))

    bet_text = pyFont.render(f'Your bet = {bet_amount}', True, (0, 0, 0), (255, 255, 255))
    bet_text_rect = bet_text.get_rect(center=(width // 2, bet_button2_rect.bottom + 25))

    color_text = pyFont.render('Choose color:', True, (0, 0, 0), (255, 255, 255))
    color_text_rect = color_text.get_rect(center=(width // 2, bet_text_rect.bottom + 50))

    black_color_text = pyFont.render('Black', True, (255, 255, 255), (0, 0, 0))
    black_color_text_rect = black_color_text.get_rect(
        center=(black_color_text.get_width() / 2, color_text_rect.bottom + 25))
    black_color_text2 = pyFontSmall.render('x1', True, (255, 255, 255), (0, 0, 0))
    black_color_text2_rect = black_color_text2.get_rect(
        center=(black_color_text.get_width() / 2, black_color_text_rect.bottom + (black_color_text2.get_height() / 2)))

    red_color_text = pyFont.render('Red', True, (255, 255, 255), (0, 0, 0))
    red_color_text_rect = red_color_text.get_rect(center=(width // 2, color_text_rect.bottom + 25))
    red_color_text2 = pyFontSmall.render('x1', True, (255, 255, 255), (0, 0, 0))
    red_color_text2_rect = red_color_text2.get_rect(
        center=(width // 2, red_color_text_rect.bottom + (red_color_text2.get_height() / 2)))

    green_color_text = pyFont.render('Green', True, (255, 255, 255), (0, 0, 0))
    green_color_text_rect = green_color_text.get_rect(
        center=(width - green_color_text.get_width() / 2, color_text_rect.bottom + 25))
    green_color_text2 = pyFontSmall.render('x2', True, (255, 255, 255), (0, 0, 0))
    green_color_text2_rect = green_color_text2.get_rect(center=(
    width - green_color_text.get_width() / 2, green_color_text_rect.bottom + (green_color_text2.get_height() / 2)))

    play_button = pyFontBig.render('PRESS BET!', True, (255, 255, 255), (0, 0, 0))
    play_button_rect = play_button.get_rect(center=(width // 2, height - (play_button.get_height() / 2) - 10))

    button_pressed = False

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.game_menu()
            if bet_button_rect.collidepoint(mouse_pos) or bet_button2_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    with open('money.txt', 'r') as money:
                        lines = money.readlines()
                        line_money = int(lines[0].strip())

                    # bet_amount = simpledialog.askinteger("Enter your bet", "Enter your bet:", parent=root, minvalue=5,
                    #                                      maxvalue=line_money)

                    minvalue = 5
                    maxvalue = 500
                    bet_amount = simpledialog.askinteger("Enter your bet", "Enter your bet:", parent=root)
                    if bet_amount is None:
                        messagebox.showerror('ERROR', 'No bet entered.')
                        bet_amount = 0
                    elif bet_amount > maxvalue:
                        messagebox.showerror('ERROR', f'Minimum bet {minvalue}$.')
                        bet_amount = 0
                    elif bet_amount > maxvalue:
                        messagebox.showerror('ERROR', f'Maximum bet {maxvalue}$.')
                        bet_amount = 0
                    elif bet_amount > line_money:
                        messagebox.showerror('ERROR', f"You don't have enough money. You only have {line_money}$.")
                        bet_amount = 0
                    bet_text = pyFont.render(f'Your bet = {bet_amount}', True, (0, 0, 0), (255, 255, 255))

            if black_color_text_rect.collidepoint(mouse_pos) or black_color_text2_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    color[0] = 'black'
                    color[1] = True
            if red_color_text_rect.collidepoint(mouse_pos) or red_color_text2_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    color[0] = 'red'
                    color[1] = True
            if green_color_text_rect.collidepoint(mouse_pos) or green_color_text2_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    color[0] = 'green'
                    color[1] = True
            if play_button_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    if bet_amount != None and color[1] == True:
                        number = random.randint(1, 37)
                        if number <= 18 and color[0] == 'black':
                            result_def(screen, 'won')
                        elif number >= 19 and number <= 36 and color[0] == 'red':
                            result_def(screen, 'won')
                        elif number == 37 and color[0] == 'green':
                            result_def(screen, 'won')
                        else:
                            result_def(screen, 'lose')
                    elif bet_amount == 0 and color[1] == True:
                        messagebox.showinfo('ERROR', 'Enter your bet!')
                    elif bet_amount != 0 and color[1] == False:
                        messagebox.showinfo('ERROR', 'Choose color!')
                    elif bet_amount == 0 and color[1] == False:
                        messagebox.showinfo('ERROR', 'Enter your bet and choose color!')

        screen.blit(bg, (0, 0))

        screen.blit(cross, cross_rect)

        screen.blit(casino_text, casino_text_rect)
        screen.blit(casino_text2, casino_text2_rect)
        screen.blit(casino_text3, casino_text3_rect)
        screen.blit(casino_text4, casino_text4_rect)

        screen.blit(bet_button, bet_button_rect)
        screen.blit(bet_button2, bet_button2_rect)

        screen.blit(bet_text, bet_text_rect)

        if color[0] == 'black':
            black_color_text = pyFont.render('Black', True, (0, 255, 0), (0, 0, 0))
            black_color_text2 = pyFontSmall.render('x1', True, (0, 255, 0), (0, 0, 0))

            red_color_text = pyFont.render('Red', True, (255, 255, 255), (0, 0, 0))
            red_color_text2 = pyFontSmall.render('x1', True, (255, 255, 255), (0, 0, 0))

            green_color_text = pyFont.render('Green', True, (255, 255, 255), (0, 0, 0))
            green_color_text2 = pyFontSmall.render('x2', True, (255, 255, 255), (0, 0, 0))

        elif color[0] == 'red':
            black_color_text = pyFont.render('Black', True, (255, 255, 255), (0, 0, 0))
            black_color_text2 = pyFontSmall.render('x1', True, (255, 255, 255), (0, 0, 0))

            red_color_text = pyFont.render('Red', True, (0, 255, 0), (0, 0, 0))
            red_color_text2 = pyFontSmall.render('x1', True, (0, 255, 0), (0, 0, 0))

            green_color_text = pyFont.render('Green', True, (255, 255, 255), (0, 0, 0))
            green_color_text2 = pyFontSmall.render('x2', True, (255, 255, 255), (0, 0, 0))

        elif color[0] == 'green':
            black_color_text = pyFont.render('Black', True, (255, 255, 255), (0, 0, 0))
            black_color_text2 = pyFontSmall.render('x1', True, (255, 255, 255), (0, 0, 0))

            red_color_text = pyFont.render('Red', True, (255, 255, 255), (0, 0, 0))
            red_color_text2 = pyFontSmall.render('x1', True, (255, 255, 255), (0, 0, 0))

            green_color_text = pyFont.render('Green', True, (0, 255, 0), (0, 0, 0))
            green_color_text2 = pyFontSmall.render('x2', True, (0, 255, 0), (0, 0, 0))

        screen.blit(color_text, color_text_rect)

        screen.blit(black_color_text, black_color_text_rect)
        screen.blit(black_color_text2, black_color_text2_rect)

        screen.blit(red_color_text, red_color_text_rect)
        screen.blit(red_color_text2, red_color_text2_rect)

        screen.blit(green_color_text, green_color_text_rect)
        screen.blit(green_color_text2, green_color_text2_rect)

        screen.blit(play_button, play_button_rect)

        pygame.display.flip()

def result_def(screen, result):
    width = 480
    height = 800

    bg = pygame.image.load('images/bg.png').convert()

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)

    casino_text = pyFont.render('Casino', True, (0, 0, 0), (255, 0, 0))
    casino_text_rect = casino_text.get_rect(center=(width // 2, height // 9))

    if result == 'won':
        result_text = pyFont.render('You won!', True, (0, 0, 0), (255, 255, 255))
        result_text_rect = result_text.get_rect(center=(width // 2, casino_text_rect.bottom + 50))

        if color[0] != 'green':
            with open('money.txt', 'r') as money:
                lines = money.readlines()
                line_money = int(lines[0].strip())
            line_money += bet_amount
            with open('money.txt', "w") as money:
                money.write(str(line_money))

            money_text = pyFont.render(f'You got {bet_amount}$', True, (0, 0, 0), (255, 255, 255))
            money_text_rect = money_text.get_rect(center=(width // 2, result_text_rect.bottom + 25))

        elif color[0] == 'green':
            with open('money.txt', 'r') as money:
                lines = money.readlines()
                line_money = int(lines[0].strip())
            new_bet_amount = bet_amount * 2
            line_money += new_bet_amount
            with open('money.txt', "w") as money:
                money.write(str(line_money))

            money_text = pyFont.render(f'You got {new_bet_amount}$', True, (0, 0, 0), (255, 255, 255))
            money_text_rect = money_text.get_rect(center=(width // 2, result_text_rect.bottom + 25))


    if result == 'lose':
        result_text = pyFont.render('You lose!', True, (0, 0, 0), (255, 255, 255))
        result_text_rect = result_text.get_rect(center=(width // 2, casino_text_rect.bottom + 50))

        if color[0] != 'green':
            with open('money.txt', 'r') as money:
                lines = money.readlines()
                line_money = int(lines[0].strip())
            line_money -= bet_amount
            with open('money.txt', "w") as money:
                money.write(str(line_money))

            money_text = pyFont.render(f'You lost {bet_amount}$', True, (0, 0, 0), (255, 255, 255))
            money_text_rect = money_text.get_rect(center=(width // 2, result_text_rect.bottom + 25))

        elif color[0] == 'green':
            with open('money.txt', 'r') as money:
                lines = money.readlines()
                line_money = int(lines[0].strip())
            new_bet_amount = bet_amount * 2
            line_money -= new_bet_amount
            with open('money.txt', "w") as money:
                money.write(str(line_money))

            money_text = pyFont.render(f'You lost {new_bet_amount}$', True, (0, 0, 0), (255, 255, 255))
            money_text_rect = money_text.get_rect(center=(width // 2, result_text_rect.bottom + 25))

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.game_menu()

        screen.blit(bg, (0, 0))

        screen.blit(cross, cross_rect)

        screen.blit(casino_text, casino_text_rect)

        screen.blit(result_text, result_text_rect)

        screen.blit(money_text, money_text_rect)

        pygame.display.flip()
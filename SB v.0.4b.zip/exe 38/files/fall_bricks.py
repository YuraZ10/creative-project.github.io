import pygame
import sys
import random


def fall_bricks_menu(screen):
    width = 480
    height = 800

    bg = pygame.image.load('images/bg.png').convert()

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)
    pyFontSmall = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22)
    pyFontBig = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 66)

    mini_game_text = pyFont.render('Fall Bricks', True, (0, 0, 0), (255, 128, 0))
    mini_game_text_rect = mini_game_text.get_rect(center=(width // 2, cross_rect.bottom + 50))

    mini_game_text2 = pyFont.render('Goal: dodge bricks', True, (0, 0, 0), (255, 255, 255))
    mini_game_text2_rect = mini_game_text2.get_rect(center=(width // 2, mini_game_text_rect.bottom + 50))

    mini_game_text3 = pyFont.render('Move: A, D or', True, (0, 0, 0), (255, 255, 255))
    mini_game_text3_rect = mini_game_text3.get_rect(
        center=(width / 2, mini_game_text2_rect.bottom + 50))

    mini_game_text4 = pyFont.render('arrows Left, Right.', True, (0, 0, 0), (255, 255, 255))
    mini_game_text4_rect = mini_game_text4.get_rect(
        center=(width / 2, mini_game_text3_rect.bottom + 25))

    play_button = pyFontBig.render('PLAY!', True, (255, 255, 255), (0, 0, 0))
    play_button_rect = play_button.get_rect(center=(width // 2, height - (play_button.get_height() / 2) - 100))

    button_pressed = False

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.game_menu()
            if play_button_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    fall_bricks(screen)

            screen.blit(bg, (0, 0))

            screen.blit(cross, cross_rect)

            screen.blit(mini_game_text, mini_game_text_rect)
            screen.blit(mini_game_text2, mini_game_text2_rect)
            screen.blit(mini_game_text3, mini_game_text3_rect)
            screen.blit(mini_game_text4, mini_game_text4_rect)

            screen.blit(play_button, play_button_rect)

            pygame.display.flip()

def fall_bricks(screen):
    global score

    width = 480
    height = 800

    bg = pygame.image.load('images/bg.png').convert()

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)

    player_width = 110
    player_height = 110
    player_x = width // 2 - player_width // 2
    player_y = height - player_height - 25

    enemy_width = 110
    enemy_height = 110
    enemy_x = width // 2 - enemy_width // 2
    enemy_y = height // 2 - enemy_height // 2
    enemies = []
    enemy_speed = 25
    enemy_spawn_rate = 10

    poses = [25, 25 + player_width + 50, 25 + player_width + 50 + player_width + 50]

    score = 0
    score_text = pyFont.render(f'Score: {score}', True, (0, 0, 0), (255, 255, 255))
    score_text_rect = score_text.get_rect(center=(width // 2, 0 + score_text.get_height() // 2))

    clock = pygame.time.Clock()
    fps = 30
    frame_count = 0

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False

        keys = pygame.key.get_just_pressed()
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            if player_x == poses[2]:
                player_x = poses[1]
            elif player_x == poses[1]:
                player_x = poses[0]

        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            if player_x == poses[0]:
                player_x = poses[1]
            elif player_x == poses[1]:
                player_x = poses[2]

        frame_count += 1
        if frame_count % enemy_spawn_rate == 0:
            line = random.randint(1, 3)
            if line == 1:
                enemy_x = poses[0]
            elif line == 2:
                enemy_x = poses[1]
            elif line == 3:
                enemy_x = poses[2]
            enemies.append([enemy_x, -enemy_height])

        new_enemies = []
        for x, y in enemies:
            if y < height:
                new_enemies.append([x, y + enemy_speed])
            else:
                score += 1

        enemies = new_enemies
        score_text = pyFont.render(f'Score: {score}', True, (0, 0, 0), (255, 255, 255))

        for enemy_x, enemy_y in enemies:
            if (player_x < enemy_x + enemy_width and player_x + enemy_width > enemy_x and
                    player_y < enemy_y + enemy_height and player_y + enemy_height > enemy_y):
                end(screen)

        screen.blit(bg, (0, 0))

        pygame.draw.rect(screen, (0, 0, 255), (player_x, player_y, player_width, player_height))
        screen.blit(score_text, score_text_rect)
        for enemy_x, enemy_y in enemies:
            pygame.draw.rect(screen, (255, 0, 0), (enemy_x, enemy_y, enemy_width, enemy_height))

        pygame.display.flip()
        clock.tick(fps)

        pygame.display.flip()

def end(screen):
    width = 480
    height = 854

    bg = pygame.image.load('images/bg.png').convert()

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)
    pyFontSmall = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22)
    pyFontBig = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 66)

    money_got = score * 5

    with open("money.txt", "r") as money:
        lines = money.readlines()
        line_money = int(lines[0].strip())
    line_money += money_got
    with open('money.txt', "w") as money:
        money.write(str(line_money))

    end_text = pyFont.render('Fall Bricks', True, (0, 0, 0), (255, 255, 255))
    end_text_rect = end_text.get_rect(center=(width // 2, cross_rect.bottom + 50))

    end_text2 = pyFont.render(f'Your score: {score}.', True, (0, 0, 0), (255, 255, 255))
    end_text2_rect = end_text2.get_rect(center=(width // 2, end_text_rect.bottom + 50))

    end_text3 = pyFont.render(f'You got {money_got}$.', True, (0, 0, 0), (255, 255, 255))
    end_text3_rect = end_text3.get_rect(center=(width // 2, end_text2_rect.bottom + 50))

    button_pressed = False

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.game_menu()

        screen.blit(bg, (0, 0))
        screen.blit(cross, cross_rect)

        screen.blit(end_text, end_text_rect)
        screen.blit(end_text2, end_text2_rect)
        screen.blit(end_text3, end_text3_rect)

        pygame.display.flip()
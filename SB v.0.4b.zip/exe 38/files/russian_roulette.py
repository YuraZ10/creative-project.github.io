import pygame
import sys
import random
import tkinter as tk
from tkinter import simpledialog
from tkinter import messagebox


def russian_roulette_menu(screen):
    global bet_amount, bet_amount2

    bet_amount = 0
    bet_amount2 = 0

    root = tk.Tk()
    root.withdraw()

    width = 480
    height = 800

    bg = pygame.image.load('images/bg.png').convert()

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)
    pyFontSmall = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22)
    pyFontBig = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 66)

    russian_roulette_text = pyFont.render('Russian Roulette', True, (0, 0, 0), (128, 128, 128))
    russian_roulette_text_rect = russian_roulette_text.get_rect(center=(width // 2, cross_rect.bottom + 50))

    russian_roulette_text2 = pyFontSmall.render('Enter your bet', True, (255, 255, 255), (0, 0, 0))
    russian_roulette_text2_rect = russian_roulette_text2.get_rect(center=(width // 2, russian_roulette_text_rect.bottom + 55))

    bet_button = pyFont.render('Click, to enter', True, (255, 255, 255), (0, 0, 0))
    bet_button_rect = bet_button.get_rect(center=(width // 2, russian_roulette_text2_rect.bottom + 50))
    bet_button2 = pyFont.render('your bet', True, (255, 255, 255), (0, 0, 0))
    bet_button2_rect = bet_button2.get_rect(center=(width // 2, bet_button_rect.bottom + (bet_button2.get_height() / 2)))

    bet_text = pyFont.render(f'Your bet = {bet_amount}', True, (0, 0, 0), (255, 255, 255))
    bet_text_rect = bet_text.get_rect(center=(width // 2, bet_button2_rect.bottom + 25))

    play_button = pyFontBig.render('PRESS BET!', True, (255, 255, 255), (0, 0, 0))
    play_button_rect = play_button.get_rect(center=(width // 2, height - (play_button.get_height() / 2) - 100))

    button_pressed = False

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.game_menu()
            if bet_button_rect.collidepoint(mouse_pos) or bet_button2_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    with open('money.txt', 'r') as money:
                        lines = money.readlines()
                        line_money = int(lines[0].strip())

                    minvalue = 5
                    maxvalue = 500
                    bet_amount = simpledialog.askinteger("Enter your bet", "Enter your bet:", parent=root)
                    bet_amount2 = bet_amount
                    if bet_amount is None:
                        messagebox.showerror('ERROR', 'No bet entered.')
                        bet_amount = 0
                    elif bet_amount < minvalue:
                        messagebox.showerror('ERROR', f'Minimum bet {minvalue}$.')
                        bet_amount = 0
                    elif bet_amount > maxvalue:
                        messagebox.showerror('ERROR', f'Maximum bet {maxvalue}$.')
                        bet_amount = 0
                    elif bet_amount > line_money:
                        messagebox.showerror('ERROR', f"You don't have enough money. You only have {line_money}$.")
                        bet_amount = 0
                    bet_text = pyFont.render(f'Your bet = {bet_amount}', True, (0, 0, 0), (255, 255, 255))

            if play_button_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    if bet_amount != 0:
                        russian_roulette(screen)
                    elif bet_amount == 0:
                        messagebox.showinfo('ERROR', 'Enter your bet!')

        screen.blit(bg, (0, 0))

        screen.blit(cross, cross_rect)

        screen.blit(russian_roulette_text, russian_roulette_text_rect)
        screen.blit(russian_roulette_text2, russian_roulette_text2_rect)

        screen.blit(bet_button, bet_button_rect)
        screen.blit(bet_button2, bet_button2_rect)
        screen.blit(bet_text, bet_text_rect)

        screen.blit(play_button, play_button_rect)

        pygame.display.flip()

def russian_roulette(screen):
    global bet_amount, bet_amount2

    width = 480
    height = 800

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)
    pyFontSmall = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22)
    pyFontBig = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 66)

    attempt = 1
    cylinder = [0, 0, 1, 0, 0, 0]

    bg = pygame.image.load('images/bg.png').convert()

    russian_roulette_text = pyFont.render('Russian Roulette', True, (0, 0, 0), (128, 128, 128))
    russian_roulette_text_rect = russian_roulette_text.get_rect(center=(width // 2, height // 9))

    attempt_text = pyFont.render(f'{attempt} attempt', True, (0, 0, 0), (255, 255, 255))
    attempt_text_rect = attempt_text.get_rect(center=(width // 2, russian_roulette_text_rect.bottom + 50))

    shoot_text = pyFont.render('Will you shoot?', True, (0, 0, 0), (255, 255, 255))
    shoot_text_rect = shoot_text.get_rect(center=(width // 2, attempt_text_rect.bottom + 50))

    yes_button = pyFont.render('Yes', True, (0, 0, 0), (0, 255, 0))
    yes_button_rect = yes_button.get_rect()
    yes_button_rect.right = width // 2 - 25
    yes_button_rect.top = shoot_text_rect.bottom + 50

    no_button = pyFont.render('No', True, (0, 0, 0), (255, 0, 0))
    no_button_rect = yes_button.get_rect()
    no_button_rect.left = width // 2 + 25
    no_button_rect.top = shoot_text_rect.bottom + 50

    result_text = None
    result_text_rect = None

    button_pressed = False

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if yes_button_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    bullet = random.choice(cylinder)
                    if bullet == 0:
                        if attempt == 1:
                            bet_amount = bet_amount2
                        elif attempt > 1:
                            bet_amount += bet_amount2
                        result_text = pyFont.render("The bullet didn't fire!", True, (0, 0, 0), (255, 255, 255))
                        result_text_rect = result_text.get_rect(center=(width // 2, yes_button_rect.bottom + 50))
                        if attempt < 5:
                            attempt += 1
                            attempt_text = pyFont.render(f'{attempt} attempt', True, (0, 0, 0), (255, 255, 255))
                        elif attempt >= 5:
                            result_def(screen, 'won')

                    elif bullet == 1:
                        result_def(screen, 'lose')

            if no_button_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    if attempt == 1:
                        import main
                        main.game_menu()
                    elif attempt > 1:
                        result_def(screen, 'won')

        screen.blit(bg, (0, 0))

        screen.blit(russian_roulette_text, russian_roulette_text_rect)
        screen.blit(attempt_text, attempt_text_rect)

        screen.blit(shoot_text, shoot_text_rect)
        screen.blit(yes_button, yes_button_rect)
        screen.blit(no_button, no_button_rect)

        if result_text:
            screen.blit(result_text, result_text_rect)

        pygame.display.flip()

def result_def(screen, result):
    global bet_amount

    width = 480
    height = 800

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 44)
    pyFontSmall = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22)
    pyFontBig = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 66)

    bg = pygame.image.load('images/bg.png').convert()

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    russian_roulette_text = pyFont.render('Russian Roulette', True, (0, 0, 0), (128, 128, 128))
    russian_roulette_text_rect = russian_roulette_text.get_rect(center=(width // 2, cross_rect.bottom + 50))

    if result == 'won':
        with open('money.txt', 'r') as money:
            lines = money.readlines()
            line_money = int(lines[0].strip())
        line_money += bet_amount
        with open('money.txt', "w") as money:
            money.write(str(line_money))

        result_text = pyFont.render('You won!', True, (0, 0, 0), (255, 255, 255))
        result_text_rect = result_text.get_rect(center=(width // 2, russian_roulette_text_rect.bottom + 50))

        money_text = pyFont.render(f'You got {bet_amount}$.', True, (0, 0, 0), (255, 255, 255))
        money_text_rect = money_text.get_rect(center=(width // 2, result_text_rect.bottom + 25))

    if result == 'lose':
        with open('money.txt', 'r') as money:
            lines = money.readlines()
            line_money = int(lines[0].strip())
        line_money -= bet_amount
        if line_money < 0:
            line_money = 0
        with open('money.txt', "w") as money:
            money.write(str(line_money))

        result_text = pyFont.render('You lose!', True, (0, 0, 0), (255, 255, 255))
        result_text_rect = result_text.get_rect(center=(width // 2, russian_roulette_text_rect.bottom + 50))

        money_text = pyFont.render(f'You lost {bet_amount}$.', True, (0, 0, 0), (255, 255, 255))
        money_text_rect = money_text.get_rect(center=(width // 2, result_text_rect.bottom + 25))

    button_pressed = False

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.game_menu()

        screen.blit(bg, (0, 0))

        screen.blit(cross, cross_rect)

        screen.blit(russian_roulette_text, russian_roulette_text_rect)

        screen.blit(result_text, result_text_rect)
        screen.blit(money_text, money_text_rect)

        pygame.display.flip()
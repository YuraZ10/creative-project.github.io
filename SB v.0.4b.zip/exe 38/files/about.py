import pygame
import sys
import webbrowser

def about(screen):
    width = 480
    height = 800

    bg = pygame.image.load('images/bg.png').convert()

    cross = pygame.image.load('images/cross.png').convert()
    cross_rect = cross.get_rect()
    cross_rect.topleft = (width - cross_rect.width, 0)

    pyFont = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 36)
    pyFontSmall = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22)
    # pyFontSmallBold = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 22, bold=True)
    pyFontBig = pygame.font.Font('Fonts\\Prompt-SemiBold.ttf', 66)

    about_text = pyFontBig.render('ABOUT', True, (0, 0, 0), (255, 255, 255))
    about_text_rect = about_text.get_rect(center=(width // 2 - 25, height // 9))

    game_text = pyFont.render('Stickman Boxes v.0.4b', True, (0, 0, 0), (255, 255, 255))
    game_text_rect = game_text.get_rect(topleft=(20, about_text_rect.bottom + 25))

    credits_text = pyFontSmall.render('CREDITS BY', True, (0, 0, 0), (255, 255, 255))
    credits_text_rect = credits_text.get_rect(topleft=(20, game_text_rect.bottom + 50))

    prog_text = pyFontSmall.render('Programming: Nuru.', True, (0, 0, 0), (255, 255, 255))
    prog_text_rect = prog_text.get_rect(topleft=(20, credits_text_rect.bottom + 10))

    cards_text = pyFontSmall.render('Cards design: Nuru, Liword, Vasiliy.', True, (0, 0, 0), (255, 255, 255))
    cards_text_rect = cards_text.get_rect(topleft=(20, prog_text_rect.bottom + 10))

    test_text = pyFontSmall.render('Testing: Liword.', True, (0, 0, 0), (255, 255, 255))
    test_text_rect = test_text.get_rect(topleft=(20, cards_text_rect.bottom + 10))

    music_text = pyFontSmall.render('Music: suno.ai.', True, (0, 0, 0), (255, 255, 255))
    music_text_rect = music_text.get_rect(topleft=(20, test_text_rect.bottom + 10))

    tg_button = pyFontSmall.render('Telegram: https://t.me/stickman_boxes', True, (255, 255, 255), (0, 0, 0))
    tg_button_rect = tg_button.get_rect(center=(width // 2, music_text_rect.bottom + 50))

    button_pressed = False

    running = True
    while running:

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                button_pressed = False
            if cross_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    import main
                    main.main_menu()
            if tg_button_rect.collidepoint(mouse_pos):
                if mouse_click[0] and not button_pressed:
                    button_pressed = True
                    webbrowser.open("https://t.me/stickman_boxes")

        screen.blit(bg, (0, 0))
        screen.blit(cross, cross_rect)

        screen.blit(about_text, about_text_rect)
        screen.blit(credits_text, credits_text_rect)
        screen.blit(game_text, game_text_rect)
        screen.blit(prog_text, prog_text_rect)
        screen.blit(cards_text, cards_text_rect)
        screen.blit(test_text, test_text_rect)
        screen.blit(music_text, music_text_rect)
        screen.blit(tg_button, tg_button_rect)

        pygame.display.flip()